import pathlib

FICTRAC_BASE_DIR = pathlib.PurePath('/media/mplitt/SSD_storage/fictrac_folder')
BRUKER_BASE_DIR = pathlib.PurePath('/media/mplitt/SSD_storage/2PData')
OUTPUT_BASE_DIR = pathlib.PurePath('/media/mplitt/SSD_storage/2P_scratch')

